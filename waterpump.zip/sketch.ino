#define waterSensor 34   // ADC pin for water level
#define pumpPin 5        // LED to represent pump

void setup() {
  pinMode(pumpPin, OUTPUT);
  Serial.begin(115200);
  Serial.println("IoT Smart Pet Feeder - Water Pump Simulation");
}

void loop() {
  int level = analogRead(waterSensor);   // Read value from 0 to 4095
  Serial.print("Water Level: ");
  Serial.println(level);

  if (level < 2000) {                    // low water threshold
    digitalWrite(pumpPin, HIGH);
    Serial.println("💧 Pump ON - Refilling water...");
  } else {
    digitalWrite(pumpPin, LOW);
    Serial.println("✅ Pump OFF - Water full");
  }

  delay(1000);
}